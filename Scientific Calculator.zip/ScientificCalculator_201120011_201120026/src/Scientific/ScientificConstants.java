
package Scientific;

import java.awt.Dimension;
import java.awt.Toolkit;


public class ScientificConstants extends javax.swing.JFrame {

    double firstnumber;
    double secondnumber;
    double result;
    String operation;
    private Object math;
 
    public ScientificConstants() {
        initComponents();
          Toolkit toolkit=getToolkit();
        Dimension size=toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        display = new javax.swing.JTextField();
        btnmn = new javax.swing.JButton();
        btnmp = new javax.swing.JButton();
        btnmmiu = new javax.swing.JButton();
        btnme = new javax.swing.JButton();
        btnc1 = new javax.swing.JButton();
        btnR = new javax.swing.JButton();
        btnre = new javax.swing.JButton();
        btnmiuB = new javax.swing.JButton();
        btnmiuN = new javax.swing.JButton();
        btnlemdac = new javax.swing.JButton();
        btnznot = new javax.swing.JButton();
        btnmiup = new javax.swing.JButton();
        btne = new javax.swing.JButton();
        btngnot = new javax.swing.JButton();
        btnsigma = new javax.swing.JButton();
        btnplunk = new javax.swing.JButton();
        btnRinfinity = new javax.swing.JButton();
        btnu = new javax.swing.JButton();
        btnlemdacn = new javax.swing.JButton();
        btnh = new javax.swing.JButton();
        btnmiumiu = new javax.swing.JButton();
        btnmiun = new javax.swing.JButton();
        btnF = new javax.swing.JButton();
        btnNA = new javax.swing.JButton();
        btng = new javax.swing.JButton();
        btnvm = new javax.swing.JButton();
        btnmiue = new javax.swing.JButton();
        btnlemdap = new javax.swing.JButton();
        btnlemdacp = new javax.swing.JButton();
        btna = new javax.swing.JButton();
        btnfsilentno = new javax.swing.JButton();
        btnK = new javax.swing.JButton();
        btnmiuno = new javax.swing.JButton();
        btnc2 = new javax.swing.JButton();
        btnanot = new javax.swing.JButton();
        btnback = new javax.swing.JButton();
        btnt = new javax.swing.JButton();
        btnpinot = new javax.swing.JButton();
        btnminus = new javax.swing.JButton();
        btncnot = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btndivide = new javax.swing.JButton();
        btnmultiplication = new javax.swing.JButton();
        btnplus = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn0 = new javax.swing.JButton();
        btndot = new javax.swing.JButton();
        btnequal = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btnG = new javax.swing.JButton();
        btnAC = new javax.swing.JButton();
        btnminus1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 0), 5));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(display, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 520, 100));

        btnmn.setBackground(new java.awt.Color(0, 102, 102));
        btnmn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmn.setForeground(new java.awt.Color(51, 0, 153));
        btnmn.setText("mn");
        btnmn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmnActionPerformed(evt);
            }
        });
        jPanel1.add(btnmn, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 60, 30));

        btnmp.setBackground(new java.awt.Color(0, 102, 102));
        btnmp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmp.setForeground(new java.awt.Color(51, 0, 153));
        btnmp.setText("mp");
        btnmp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmpActionPerformed(evt);
            }
        });
        jPanel1.add(btnmp, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 60, 30));

        btnmmiu.setBackground(new java.awt.Color(0, 102, 102));
        btnmmiu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmmiu.setForeground(new java.awt.Color(51, 0, 153));
        btnmmiu.setText("mμ");
        btnmmiu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmmiuActionPerformed(evt);
            }
        });
        jPanel1.add(btnmmiu, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 170, 60, 30));

        btnme.setBackground(new java.awt.Color(0, 102, 102));
        btnme.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnme.setForeground(new java.awt.Color(51, 0, 153));
        btnme.setText("me");
        btnme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmeActionPerformed(evt);
            }
        });
        jPanel1.add(btnme, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 170, 60, 30));

        btnc1.setBackground(new java.awt.Color(0, 102, 102));
        btnc1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnc1.setForeground(new java.awt.Color(51, 0, 153));
        btnc1.setText("c1");
        btnc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnc1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnc1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 420, 60, 30));

        btnR.setBackground(new java.awt.Color(0, 102, 102));
        btnR.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnR.setForeground(new java.awt.Color(51, 0, 153));
        btnR.setText("R");
        btnR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRActionPerformed(evt);
            }
        });
        jPanel1.add(btnR, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, 60, 30));

        btnre.setBackground(new java.awt.Color(0, 102, 102));
        btnre.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnre.setForeground(new java.awt.Color(51, 0, 153));
        btnre.setText("re");
        btnre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnreActionPerformed(evt);
            }
        });
        jPanel1.add(btnre, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 270, 60, 30));

        btnmiuB.setBackground(new java.awt.Color(0, 102, 102));
        btnmiuB.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiuB.setForeground(new java.awt.Color(51, 0, 153));
        btnmiuB.setText("μB");
        btnmiuB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiuBActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiuB, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 220, 60, 30));

        btnmiuN.setBackground(new java.awt.Color(0, 102, 102));
        btnmiuN.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiuN.setForeground(new java.awt.Color(51, 0, 153));
        btnmiuN.setText("μN");
        btnmiuN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiuNActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiuN, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 60, 30));

        btnlemdac.setBackground(new java.awt.Color(0, 102, 102));
        btnlemdac.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemdac.setForeground(new java.awt.Color(51, 0, 153));
        btnlemdac.setText("λc");
        btnlemdac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemdacActionPerformed(evt);
            }
        });
        jPanel1.add(btnlemdac, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, 60, 30));

        btnznot.setBackground(new java.awt.Color(0, 102, 102));
        btnznot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnznot.setForeground(new java.awt.Color(51, 0, 153));
        btnznot.setText("Z0");
        btnznot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnznotActionPerformed(evt);
            }
        });
        jPanel1.add(btnznot, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 320, 70, 30));

        btnmiup.setBackground(new java.awt.Color(0, 102, 102));
        btnmiup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiup.setForeground(new java.awt.Color(51, 0, 153));
        btnmiup.setText("μp");
        btnmiup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiupActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiup, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 320, 60, 30));

        btne.setBackground(new java.awt.Color(0, 102, 102));
        btne.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btne.setForeground(new java.awt.Color(51, 0, 153));
        btne.setText("e");
        btne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btneActionPerformed(evt);
            }
        });
        jPanel1.add(btne, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 370, 60, 30));

        btngnot.setBackground(new java.awt.Color(0, 102, 102));
        btngnot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btngnot.setForeground(new java.awt.Color(51, 0, 153));
        btngnot.setText("G0");
        btngnot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngnotActionPerformed(evt);
            }
        });
        jPanel1.add(btngnot, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 420, 60, 30));

        btnsigma.setBackground(new java.awt.Color(0, 102, 102));
        btnsigma.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnsigma.setForeground(new java.awt.Color(51, 0, 153));
        btnsigma.setText("σ");
        btnsigma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsigmaActionPerformed(evt);
            }
        });
        jPanel1.add(btnsigma, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, 70, 30));

        btnplunk.setBackground(new java.awt.Color(0, 102, 102));
        btnplunk.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnplunk.setForeground(new java.awt.Color(51, 0, 153));
        btnplunk.setText("plk");
        btnplunk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplunkActionPerformed(evt);
            }
        });
        jPanel1.add(btnplunk, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, 60, 30));

        btnRinfinity.setBackground(new java.awt.Color(0, 102, 102));
        btnRinfinity.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnRinfinity.setForeground(new java.awt.Color(51, 0, 153));
        btnRinfinity.setText("R∞");
        btnRinfinity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRinfinityActionPerformed(evt);
            }
        });
        jPanel1.add(btnRinfinity, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 410, 80, 40));

        btnu.setBackground(new java.awt.Color(0, 102, 102));
        btnu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnu.setForeground(new java.awt.Color(51, 0, 153));
        btnu.setText("u");
        btnu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnuActionPerformed(evt);
            }
        });
        jPanel1.add(btnu, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 60, 30));

        btnlemdacn.setBackground(new java.awt.Color(0, 102, 102));
        btnlemdacn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemdacn.setForeground(new java.awt.Color(51, 0, 153));
        btnlemdacn.setText("λcn");
        btnlemdacn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemdacnActionPerformed(evt);
            }
        });
        jPanel1.add(btnlemdacn, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, 60, 30));

        btnh.setBackground(new java.awt.Color(0, 102, 102));
        btnh.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnh.setForeground(new java.awt.Color(51, 0, 153));
        btnh.setText("h");
        btnh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhActionPerformed(evt);
            }
        });
        jPanel1.add(btnh, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 60, 30));

        btnmiumiu.setBackground(new java.awt.Color(0, 102, 102));
        btnmiumiu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiumiu.setForeground(new java.awt.Color(51, 0, 153));
        btnmiumiu.setText("μμ");
        btnmiumiu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiumiuActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiumiu, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 360, 80, 40));

        btnmiun.setBackground(new java.awt.Color(0, 102, 102));
        btnmiun.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiun.setForeground(new java.awt.Color(51, 0, 153));
        btnmiun.setText("μn");
        btnmiun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiunActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiun, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 320, 60, 30));

        btnF.setBackground(new java.awt.Color(0, 102, 102));
        btnF.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnF.setForeground(new java.awt.Color(51, 0, 153));
        btnF.setText("F");
        btnF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFActionPerformed(evt);
            }
        });
        jPanel1.add(btnF, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 60, 30));

        btnNA.setBackground(new java.awt.Color(0, 102, 102));
        btnNA.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnNA.setForeground(new java.awt.Color(51, 0, 153));
        btnNA.setText("NA");
        btnNA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNAActionPerformed(evt);
            }
        });
        jPanel1.add(btnNA, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, 60, 30));

        btng.setBackground(new java.awt.Color(0, 102, 102));
        btng.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btng.setForeground(new java.awt.Color(51, 0, 153));
        btng.setText("g");
        btng.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngActionPerformed(evt);
            }
        });
        jPanel1.add(btng, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 370, 60, 30));

        btnvm.setBackground(new java.awt.Color(0, 102, 102));
        btnvm.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnvm.setForeground(new java.awt.Color(51, 0, 153));
        btnvm.setText("Vm");
        btnvm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvmActionPerformed(evt);
            }
        });
        jPanel1.add(btnvm, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 300, 80, 40));

        btnmiue.setBackground(new java.awt.Color(0, 102, 102));
        btnmiue.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiue.setForeground(new java.awt.Color(51, 0, 153));
        btnmiue.setText("μe");
        btnmiue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiueActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiue, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, 60, 30));

        btnlemdap.setBackground(new java.awt.Color(0, 102, 102));
        btnlemdap.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemdap.setForeground(new java.awt.Color(51, 0, 153));
        btnlemdap.setText("γp");
        btnlemdap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemdapActionPerformed(evt);
            }
        });
        jPanel1.add(btnlemdap, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 270, 60, 30));

        btnlemdacp.setBackground(new java.awt.Color(0, 102, 102));
        btnlemdacp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemdacp.setForeground(new java.awt.Color(51, 0, 153));
        btnlemdacp.setText("λcp");
        btnlemdacp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemdacpActionPerformed(evt);
            }
        });
        jPanel1.add(btnlemdacp, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 60, 30));

        btna.setBackground(new java.awt.Color(0, 102, 102));
        btna.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btna.setForeground(new java.awt.Color(51, 0, 153));
        btna.setText("α");
        btna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnaActionPerformed(evt);
            }
        });
        jPanel1.add(btna, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 220, 60, 30));

        btnfsilentno.setBackground(new java.awt.Color(0, 102, 102));
        btnfsilentno.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnfsilentno.setForeground(new java.awt.Color(51, 0, 153));
        btnfsilentno.setText("ε0");
        btnfsilentno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfsilentnoActionPerformed(evt);
            }
        });
        jPanel1.add(btnfsilentno, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 70, 30));

        btnK.setBackground(new java.awt.Color(0, 102, 102));
        btnK.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnK.setForeground(new java.awt.Color(51, 0, 153));
        btnK.setText("k");
        btnK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKActionPerformed(evt);
            }
        });
        jPanel1.add(btnK, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 370, 60, 30));

        btnmiuno.setBackground(new java.awt.Color(0, 102, 102));
        btnmiuno.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnmiuno.setForeground(new java.awt.Color(51, 0, 153));
        btnmiuno.setText("μ0");
        btnmiuno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmiunoActionPerformed(evt);
            }
        });
        jPanel1.add(btnmiuno, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 270, 70, 30));

        btnc2.setBackground(new java.awt.Color(0, 102, 102));
        btnc2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnc2.setForeground(new java.awt.Color(51, 0, 153));
        btnc2.setText("c2");
        btnc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnc2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnc2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 420, 60, 30));

        btnanot.setBackground(new java.awt.Color(0, 102, 102));
        btnanot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnanot.setForeground(new java.awt.Color(51, 0, 153));
        btnanot.setText("a0");
        btnanot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnanotActionPerformed(evt);
            }
        });
        jPanel1.add(btnanot, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 170, 60, 30));

        btnback.setBackground(new java.awt.Color(0, 0, 153));
        btnback.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnback.setForeground(new java.awt.Color(0, 153, 0));
        btnback.setText("back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        jPanel1.add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 490, 110, 40));

        btnt.setBackground(new java.awt.Color(0, 102, 102));
        btnt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnt.setForeground(new java.awt.Color(51, 0, 153));
        btnt.setText("t");
        btnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntActionPerformed(evt);
            }
        });
        jPanel1.add(btnt, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 370, 70, 30));

        btnpinot.setBackground(new java.awt.Color(0, 102, 102));
        btnpinot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnpinot.setForeground(new java.awt.Color(51, 0, 153));
        btnpinot.setText("Φ0");
        btnpinot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpinotActionPerformed(evt);
            }
        });
        jPanel1.add(btnpinot, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 320, 60, 30));

        btnminus.setBackground(new java.awt.Color(0, 102, 51));
        btnminus.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnminus.setForeground(new java.awt.Color(204, 0, 0));
        btnminus.setText("√");
        jPanel1.add(btnminus, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 690, 70, 40));

        btncnot.setBackground(new java.awt.Color(0, 102, 102));
        btncnot.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btncnot.setForeground(new java.awt.Color(51, 0, 153));
        btncnot.setText("c0");
        btncnot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncnotActionPerformed(evt);
            }
        });
        jPanel1.add(btncnot, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 420, 60, 30));

        btn8.setBackground(new java.awt.Color(0, 102, 102));
        btn8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn8.setForeground(new java.awt.Color(255, 255, 255));
        btn8.setText("8");
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });
        jPanel1.add(btn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 490, 60, 50));

        btn9.setBackground(new java.awt.Color(0, 102, 102));
        btn9.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn9.setForeground(new java.awt.Color(255, 255, 255));
        btn9.setText("9");
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });
        jPanel1.add(btn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 490, 60, 50));

        btndivide.setBackground(new java.awt.Color(0, 102, 51));
        btndivide.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btndivide.setForeground(new java.awt.Color(204, 0, 0));
        btndivide.setText("/");
        btndivide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndivideActionPerformed(evt);
            }
        });
        jPanel1.add(btndivide, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 490, 70, 50));

        btnmultiplication.setBackground(new java.awt.Color(0, 102, 51));
        btnmultiplication.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnmultiplication.setForeground(new java.awt.Color(204, 0, 0));
        btnmultiplication.setText("*");
        btnmultiplication.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmultiplicationActionPerformed(evt);
            }
        });
        jPanel1.add(btnmultiplication, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 560, 70, 50));

        btnplus.setBackground(new java.awt.Color(0, 102, 51));
        btnplus.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnplus.setForeground(new java.awt.Color(204, 0, 0));
        btnplus.setText("+");
        btnplus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplusActionPerformed(evt);
            }
        });
        jPanel1.add(btnplus, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 590, 60, 140));

        btn4.setBackground(new java.awt.Color(0, 102, 102));
        btn4.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn4.setForeground(new java.awt.Color(255, 255, 255));
        btn4.setText("4");
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        jPanel1.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 560, 60, 50));

        btn1.setBackground(new java.awt.Color(0, 102, 102));
        btn1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn1.setForeground(new java.awt.Color(255, 255, 255));
        btn1.setText("1");
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 620, 60, 50));

        btn2.setBackground(new java.awt.Color(0, 102, 102));
        btn2.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn2.setForeground(new java.awt.Color(255, 255, 255));
        btn2.setText("2");
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        jPanel1.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 620, 60, 50));

        btn3.setBackground(new java.awt.Color(0, 102, 102));
        btn3.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn3.setForeground(new java.awt.Color(255, 255, 255));
        btn3.setText("3");
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        jPanel1.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 620, 60, 50));

        btn5.setBackground(new java.awt.Color(0, 102, 102));
        btn5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn5.setForeground(new java.awt.Color(255, 255, 255));
        btn5.setText("5");
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        jPanel1.add(btn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 560, 60, 50));

        btn0.setBackground(new java.awt.Color(0, 102, 102));
        btn0.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn0.setForeground(new java.awt.Color(255, 255, 255));
        btn0.setText("0");
        btn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn0ActionPerformed(evt);
            }
        });
        jPanel1.add(btn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 680, 60, 50));

        btndot.setBackground(new java.awt.Color(0, 102, 102));
        btndot.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btndot.setForeground(new java.awt.Color(255, 255, 255));
        btndot.setText(".");
        btndot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndotActionPerformed(evt);
            }
        });
        jPanel1.add(btndot, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 680, 60, 50));

        btnequal.setBackground(new java.awt.Color(0, 102, 102));
        btnequal.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnequal.setForeground(new java.awt.Color(255, 255, 255));
        btnequal.setText("=");
        btnequal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnequalActionPerformed(evt);
            }
        });
        jPanel1.add(btnequal, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 680, 100, 50));

        btn6.setBackground(new java.awt.Color(0, 102, 102));
        btn6.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn6.setForeground(new java.awt.Color(255, 255, 255));
        btn6.setText("6");
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });
        jPanel1.add(btn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 560, 60, 50));

        btn7.setBackground(new java.awt.Color(0, 102, 102));
        btn7.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btn7.setForeground(new java.awt.Color(255, 255, 255));
        btn7.setText("7");
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });
        jPanel1.add(btn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 60, 50));

        btnG.setBackground(new java.awt.Color(0, 102, 102));
        btnG.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnG.setForeground(new java.awt.Color(51, 0, 153));
        btnG.setText("G");
        btnG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGActionPerformed(evt);
            }
        });
        jPanel1.add(btnG, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 420, 70, 30));

        btnAC.setBackground(new java.awt.Color(0, 0, 153));
        btnAC.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnAC.setForeground(new java.awt.Color(0, 153, 0));
        btnAC.setText("AC");
        btnAC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnACActionPerformed(evt);
            }
        });
        jPanel1.add(btnAC, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 160, 80, 130));

        btnminus1.setBackground(new java.awt.Color(0, 102, 51));
        btnminus1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnminus1.setForeground(new java.awt.Color(204, 0, 0));
        btnminus1.setText("-");
        btnminus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnminus1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnminus1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 630, 70, 40));

        jButton1.setBackground(new java.awt.Color(204, 51, 0));
        jButton1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 102, 0));
        jButton1.setText("GO BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 100, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 756, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn0ActionPerformed
      
        String num = display.getText()+btn0.getText();
        display.setText(num);      
    }//GEN-LAST:event_btn0ActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
      
        String num = display.getText()+btn1.getText();
        display.setText(num);      
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
   
        String num = display.getText()+btn2.getText();
        display.setText(num);
        
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
     
        String num = display.getText()+btn3.getText();
        display.setText(num);
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
      
        String num = display.getText()+btn4.getText();
        display.setText(num);
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
       
        String num = display.getText()+btn5.getText();
        display.setText(num);
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
       
        String num = display.getText()+btn6.getText();
        display.setText(num);
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
     
        String num = display.getText()+btn7.getText();
        display.setText(num);
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
       
        String num = display.getText()+btn8.getText();
        display.setText(num);
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
        
        String num = display.getText()+btn9.getText();
        display.setText(num);
    }//GEN-LAST:event_btn9ActionPerformed

    private void btnplusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplusActionPerformed
        
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("+");
    }//GEN-LAST:event_btnplusActionPerformed

    private void btnminus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnminus1ActionPerformed
       
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("-");
    }//GEN-LAST:event_btnminus1ActionPerformed

    private void btnmultiplicationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmultiplicationActionPerformed
       
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("*");
    }//GEN-LAST:event_btnmultiplicationActionPerformed

    private void btndivideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndivideActionPerformed
 
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("/");
    }//GEN-LAST:event_btndivideActionPerformed

    private void btnequalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnequalActionPerformed
     
         String g12;
        secondnumber=Double.parseDouble(display.getText());
        
        if(operation=="+")
        {
            result=firstnumber+secondnumber;
            g12=String.format("%.2f",result);
            display.setText(g12);
        }
        else if(operation=="-")
        {
             result=firstnumber-secondnumber;
            g12=String.format("%.2f",result);
            display.setText(g12);
        }
         else if(operation=="*")
        {
             result=firstnumber*secondnumber;
            g12=String.format("%.2f",result);
            display.setText(g12);
        }
         else if(operation=="/")
        {
             result=firstnumber/secondnumber;
            g12=String.format("%.2f",result);
            display.setText(g12);
        }
         else if(operation=="%")
        {
             result=firstnumber%secondnumber;
            g12=String.format("%.2f",result);
            display.setText(g12);
        }
    }//GEN-LAST:event_btnequalActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
    
         String bsp=null;
        
        if(display.getText().length()>0)
        {
            StringBuilder ns = new StringBuilder(display.getText());
            ns.deleteCharAt(display.getText().length()-1);
            bsp=ns.toString();
            display.setText(bsp);
        }
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnACActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnACActionPerformed
  
        display.setText("0");
    }//GEN-LAST:event_btnACActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new scientific_Cal().setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnmpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmpActionPerformed
        
        double  pm=1.67*Math.pow(10,-27);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmpActionPerformed

    private void btnmnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmnActionPerformed
        // TODO add your handling code here:
        double pm;
        pm=1.674*Math.pow(10,-27);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmnActionPerformed

    private void btnmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmeActionPerformed
       
          double pm;
        pm=9.11*Math.pow(10,-31);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmeActionPerformed

    private void btnmmiuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmmiuActionPerformed
     
         double pm;
        pm=105.66*(Math.pow(10, 6)/(3*Math.pow(10,8)));
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmmiuActionPerformed

    private void btnanotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnanotActionPerformed
      double pm;
         pm=5.291*Math.pow(10, -11);
         display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnanotActionPerformed

    private void btnsigmaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsigmaActionPerformed
       
          double pm=5.67*Math.pow(10,-8);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnsigmaActionPerformed

    private void btnhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhActionPerformed
       
        double pm;
        pm= 6.62607015*Math.pow(10, -34);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnhActionPerformed

    private void btnmiuNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiuNActionPerformed
       
         
        double pm;
        pm=5.0507836*Math.pow(10, -27);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiuNActionPerformed

    private void btnmiuBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiuBActionPerformed
       
         double pm=9.274*Math.pow(10, -24);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiuBActionPerformed

    private void btnplunkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplunkActionPerformed
      
         double pm= 6.626*Math.pow(10,-34);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnplunkActionPerformed

    private void btnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnaActionPerformed
      
        double pm=0.00729;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnaActionPerformed

    private void btnfsilentnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfsilentnoActionPerformed
       
        double pm=8.854*Math.pow(10,-12);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnfsilentnoActionPerformed

    private void btnreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnreActionPerformed
       
         double pm=2.82*Math.pow(10, -15);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnreActionPerformed

    private void btnlemdacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemdacActionPerformed
     
        double pm=2.42631023867*Math.pow(10, -12);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlemdacActionPerformed

    private void btnlemdapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemdapActionPerformed
      
         double pm=2.675*Math.pow(10,8);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlemdapActionPerformed

    private void btnlemdacpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemdacpActionPerformed
       
           double pm=1.319*Math.pow(10,-15);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlemdacpActionPerformed

    private void btnlemdacnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemdacnActionPerformed
     
         double pm=1.319*Math.pow(10,-15);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlemdacnActionPerformed

    private void btnmiunoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiunoActionPerformed
        
        double pm= 1.257*Math.pow(10,-6);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiunoActionPerformed

    private void btnuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnuActionPerformed
        // TODO add your handling code here:
        double pm=1.66053904020*Math.pow(10,-27);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnuActionPerformed

    private void btnmiupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiupActionPerformed
   
        double pm=1.4101*Math.pow(10,-26);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiupActionPerformed

    private void btnmiueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiueActionPerformed
       
          double pm=-9.285*Math.pow(10,-24);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiueActionPerformed

    private void btnmiunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiunActionPerformed
      
         double pm=-9.662*Math.pow(10,-27);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiunActionPerformed

    private void btnpinotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpinotActionPerformed
     
         double pm= 2.067*Math.pow(10,-15);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnpinotActionPerformed

    private void btnznotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnznotActionPerformed
      
        double pm=376.730;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnznotActionPerformed

    private void btnvmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvmActionPerformed
     
         double pm=22.4;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnvmActionPerformed

    private void btnFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFActionPerformed
        
        double pm=96485.33;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnFActionPerformed

    private void btneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btneActionPerformed
      
         double pm=1.602*Math.pow(10,-19);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btneActionPerformed

    private void btnNAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNAActionPerformed
       
         double pm=6.02*Math.pow(10,23);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnNAActionPerformed

    private void btnKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKActionPerformed
      
        double pm=1.38*Math.pow(10,-23);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnKActionPerformed

    private void btngActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngActionPerformed
        
        double pm= 9.8;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btngActionPerformed

    private void btntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntActionPerformed
   
        double pm=33.8;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btntActionPerformed

    private void btnmiumiuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmiumiuActionPerformed
    
        double pm=116591*Math.pow(10,-12);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnmiumiuActionPerformed

    private void btnRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRActionPerformed
       
        double pm=8.314;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnRActionPerformed

    private void btncnotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncnotActionPerformed
       
        double pm=3*Math.pow(10,8);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btncnotActionPerformed

    private void btnc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnc1ActionPerformed
       
         double pm=3.741*Math.pow(10,-16);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnc1ActionPerformed

    private void btnc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnc2ActionPerformed
      
        double pm= 1.438*Math.pow(10,-2);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnc2ActionPerformed

    private void btngnotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngnotActionPerformed
    
        double  pm=7.748*Math.pow(10,-5);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btngnotActionPerformed

    private void btnGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGActionPerformed
     
         double pm= 6.67*Math.pow(10,-11);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnGActionPerformed

    private void btnRinfinityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRinfinityActionPerformed
       
         double pm=10973731.56;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnRinfinityActionPerformed

    private void btndotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndotActionPerformed
      
          if(!display.getText().contains("."))
        {
            display.setText(display.getText()+btndot.getText());
        }
    }//GEN-LAST:event_btndotActionPerformed

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScientificConstants().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn0;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btnAC;
    private javax.swing.JButton btnF;
    private javax.swing.JButton btnG;
    private javax.swing.JButton btnK;
    private javax.swing.JButton btnNA;
    private javax.swing.JButton btnR;
    private javax.swing.JButton btnRinfinity;
    private javax.swing.JButton btna;
    private javax.swing.JButton btnanot;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnc1;
    private javax.swing.JButton btnc2;
    private javax.swing.JButton btncnot;
    private javax.swing.JButton btndivide;
    private javax.swing.JButton btndot;
    private javax.swing.JButton btne;
    private javax.swing.JButton btnequal;
    private javax.swing.JButton btnfsilentno;
    private javax.swing.JButton btng;
    private javax.swing.JButton btngnot;
    private javax.swing.JButton btnh;
    private javax.swing.JButton btnlemdac;
    private javax.swing.JButton btnlemdacn;
    private javax.swing.JButton btnlemdacp;
    private javax.swing.JButton btnlemdap;
    private javax.swing.JButton btnme;
    private javax.swing.JButton btnminus;
    private javax.swing.JButton btnminus1;
    private javax.swing.JButton btnmiuB;
    private javax.swing.JButton btnmiuN;
    private javax.swing.JButton btnmiue;
    private javax.swing.JButton btnmiumiu;
    private javax.swing.JButton btnmiun;
    private javax.swing.JButton btnmiuno;
    private javax.swing.JButton btnmiup;
    private javax.swing.JButton btnmmiu;
    private javax.swing.JButton btnmn;
    private javax.swing.JButton btnmp;
    private javax.swing.JButton btnmultiplication;
    private javax.swing.JButton btnpinot;
    private javax.swing.JButton btnplunk;
    private javax.swing.JButton btnplus;
    private javax.swing.JButton btnre;
    private javax.swing.JButton btnsigma;
    private javax.swing.JButton btnt;
    private javax.swing.JButton btnu;
    private javax.swing.JButton btnvm;
    private javax.swing.JButton btnznot;
    private javax.swing.JTextField display;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
