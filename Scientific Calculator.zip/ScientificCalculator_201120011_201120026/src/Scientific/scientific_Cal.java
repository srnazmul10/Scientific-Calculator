
package Scientific;

import java.awt.Dimension;
import java.awt.Toolkit;



public class scientific_Cal extends javax.swing.JFrame {
    double firstnumber;
    double secondnumber;
    double result;
    String operation;
    private Object math;

   
    public scientific_Cal() {
        initComponents();
         Toolkit toolkit=getToolkit();
        Dimension size=toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
        
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        display = new javax.swing.JTextField();
        btnNormal = new javax.swing.JButton();
        btnAC1 = new javax.swing.JButton();
        btnhexa = new javax.swing.JButton();
        btnoctal = new javax.swing.JButton();
        btnbinary = new javax.swing.JButton();
        btnln = new javax.swing.JButton();
        btnconstant = new javax.swing.JButton();
        btnsin = new javax.swing.JButton();
        btncos = new javax.swing.JButton();
        btntan = new javax.swing.JButton();
        btnlog = new javax.swing.JButton();
        btnconversion = new javax.swing.JButton();
        btnsininverse = new javax.swing.JButton();
        btncosinverse = new javax.swing.JButton();
        btntaninverse = new javax.swing.JButton();
        btnrund = new javax.swing.JButton();
        btnroot = new javax.swing.JButton();
        btnquebe = new javax.swing.JButton();
        btninverse = new javax.swing.JButton();
        btnsquare = new javax.swing.JButton();
        btnn = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn8 = new javax.swing.JButton();
        btn9 = new javax.swing.JButton();
        btnmultiplication = new javax.swing.JButton();
        btndivide = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        btn5 = new javax.swing.JButton();
        btn6 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btnpi = new javax.swing.JButton();
        btndot = new javax.swing.JButton();
        btn0 = new javax.swing.JButton();
        btnplus = new javax.swing.JButton();
        btnminus = new javax.swing.JButton();
        btnback = new javax.swing.JButton();
        btnequal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 0), 5));
        jPanel2.setForeground(new java.awt.Color(153, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        display.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        display.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayActionPerformed(evt);
            }
        });
        jPanel2.add(display, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 530, 83));

        btnNormal.setBackground(new java.awt.Color(0, 51, 51));
        btnNormal.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnNormal.setForeground(new java.awt.Color(255, 0, 255));
        btnNormal.setText("Go Back");
        btnNormal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNormalActionPerformed(evt);
            }
        });
        jPanel2.add(btnNormal, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 120, 40));

        btnAC1.setBackground(new java.awt.Color(0, 51, 51));
        btnAC1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnAC1.setForeground(new java.awt.Color(255, 0, 255));
        btnAC1.setText("AC");
        btnAC1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAC1ActionPerformed(evt);
            }
        });
        jPanel2.add(btnAC1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 120, 40));

        btnhexa.setBackground(new java.awt.Color(0, 102, 102));
        btnhexa.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnhexa.setForeground(new java.awt.Color(255, 255, 255));
        btnhexa.setText("hexa");
        btnhexa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhexaActionPerformed(evt);
            }
        });
        jPanel2.add(btnhexa, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        btnoctal.setBackground(new java.awt.Color(0, 102, 102));
        btnoctal.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnoctal.setForeground(new java.awt.Color(255, 255, 255));
        btnoctal.setText("octal");
        btnoctal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnoctalActionPerformed(evt);
            }
        });
        jPanel2.add(btnoctal, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 160, 80, -1));

        btnbinary.setBackground(new java.awt.Color(0, 102, 102));
        btnbinary.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnbinary.setForeground(new java.awt.Color(255, 255, 255));
        btnbinary.setText("binary");
        btnbinary.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbinaryActionPerformed(evt);
            }
        });
        jPanel2.add(btnbinary, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 160, -1, -1));

        btnln.setBackground(new java.awt.Color(0, 102, 102));
        btnln.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnln.setForeground(new java.awt.Color(255, 255, 255));
        btnln.setText("ln(x)");
        btnln.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlnActionPerformed(evt);
            }
        });
        jPanel2.add(btnln, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 160, 80, -1));

        btnconstant.setBackground(new java.awt.Color(0, 51, 51));
        btnconstant.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnconstant.setForeground(new java.awt.Color(255, 0, 255));
        btnconstant.setText("constant");
        btnconstant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconstantActionPerformed(evt);
            }
        });
        jPanel2.add(btnconstant, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 120, 50));

        btnsin.setBackground(new java.awt.Color(0, 102, 102));
        btnsin.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnsin.setForeground(new java.awt.Color(255, 255, 255));
        btnsin.setText("sin");
        btnsin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsinActionPerformed(evt);
            }
        });
        jPanel2.add(btnsin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 70, -1));

        btncos.setBackground(new java.awt.Color(0, 102, 102));
        btncos.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btncos.setForeground(new java.awt.Color(255, 255, 255));
        btncos.setText("cos");
        btncos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncosActionPerformed(evt);
            }
        });
        jPanel2.add(btncos, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 220, 80, -1));

        btntan.setBackground(new java.awt.Color(0, 102, 102));
        btntan.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btntan.setForeground(new java.awt.Color(255, 255, 255));
        btntan.setText("tan");
        btntan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntanActionPerformed(evt);
            }
        });
        jPanel2.add(btntan, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, 80, -1));

        btnlog.setBackground(new java.awt.Color(0, 102, 102));
        btnlog.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlog.setForeground(new java.awt.Color(255, 255, 255));
        btnlog.setText("log");
        btnlog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlogActionPerformed(evt);
            }
        });
        jPanel2.add(btnlog, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 220, 80, -1));

        btnconversion.setBackground(new java.awt.Color(0, 51, 51));
        btnconversion.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnconversion.setForeground(new java.awt.Color(255, 0, 255));
        btnconversion.setText("Conversion");
        btnconversion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconversionActionPerformed(evt);
            }
        });
        jPanel2.add(btnconversion, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 260, -1, 50));

        btnsininverse.setBackground(new java.awt.Color(0, 102, 102));
        btnsininverse.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnsininverse.setForeground(new java.awt.Color(255, 255, 255));
        btnsininverse.setText("sin^-1");
        btnsininverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsininverseActionPerformed(evt);
            }
        });
        jPanel2.add(btnsininverse, new org.netbeans.lib.awtextra.AbsoluteConstraints(19, 280, 80, -1));

        btncosinverse.setBackground(new java.awt.Color(0, 102, 102));
        btncosinverse.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btncosinverse.setForeground(new java.awt.Color(255, 255, 255));
        btncosinverse.setText("cos^-1");
        btncosinverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncosinverseActionPerformed(evt);
            }
        });
        jPanel2.add(btncosinverse, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 280, 80, -1));

        btntaninverse.setBackground(new java.awt.Color(0, 102, 102));
        btntaninverse.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btntaninverse.setForeground(new java.awt.Color(255, 255, 255));
        btntaninverse.setText("tan^-1");
        btntaninverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btntaninverseActionPerformed(evt);
            }
        });
        jPanel2.add(btntaninverse, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, -1, -1));

        btnrund.setBackground(new java.awt.Color(0, 102, 102));
        btnrund.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnrund.setForeground(new java.awt.Color(255, 255, 255));
        btnrund.setText("Rund");
        btnrund.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrundActionPerformed(evt);
            }
        });
        jPanel2.add(btnrund, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 280, 80, -1));

        btnroot.setBackground(new java.awt.Color(153, 0, 0));
        btnroot.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnroot.setForeground(new java.awt.Color(0, 0, 102));
        btnroot.setText("√");
        btnroot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrootActionPerformed(evt);
            }
        });
        jPanel2.add(btnroot, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 341, 60, 40));

        btnquebe.setBackground(new java.awt.Color(153, 0, 0));
        btnquebe.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnquebe.setForeground(new java.awt.Color(0, 0, 102));
        btnquebe.setText("x^3");
        btnquebe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnquebeActionPerformed(evt);
            }
        });
        jPanel2.add(btnquebe, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, -1, 40));

        btninverse.setBackground(new java.awt.Color(153, 0, 0));
        btninverse.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btninverse.setForeground(new java.awt.Color(0, 0, 102));
        btninverse.setText("x^-1");
        btninverse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninverseActionPerformed(evt);
            }
        });
        jPanel2.add(btninverse, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 341, 70, 40));

        btnsquare.setBackground(new java.awt.Color(153, 0, 0));
        btnsquare.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnsquare.setForeground(new java.awt.Color(0, 0, 102));
        btnsquare.setText("x^2");
        btnsquare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsquareActionPerformed(evt);
            }
        });
        jPanel2.add(btnsquare, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 341, 70, 40));

        btnn.setBackground(new java.awt.Color(153, 0, 0));
        btnn.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnn.setForeground(new java.awt.Color(0, 0, 102));
        btnn.setText("x^n");
        btnn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnActionPerformed(evt);
            }
        });
        jPanel2.add(btnn, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 340, 80, 40));

        btn7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn7.setForeground(new java.awt.Color(153, 0, 0));
        btn7.setText("7");
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });
        jPanel2.add(btn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 440, -1, -1));

        btn8.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn8.setForeground(new java.awt.Color(153, 0, 0));
        btn8.setText("8");
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });
        jPanel2.add(btn8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 440, -1, -1));

        btn9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn9.setForeground(new java.awt.Color(153, 0, 0));
        btn9.setText("9");
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });
        jPanel2.add(btn9, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 440, -1, -1));

        btnmultiplication.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnmultiplication.setForeground(new java.awt.Color(153, 0, 0));
        btnmultiplication.setText("*");
        btnmultiplication.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmultiplicationActionPerformed(evt);
            }
        });
        jPanel2.add(btnmultiplication, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 430, 50, 50));

        btndivide.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btndivide.setForeground(new java.awt.Color(153, 0, 0));
        btndivide.setText("/");
        btndivide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndivideActionPerformed(evt);
            }
        });
        jPanel2.add(btndivide, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 430, 50, 50));

        btn4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn4.setForeground(new java.awt.Color(153, 0, 0));
        btn4.setText("4");
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        jPanel2.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, -1, -1));

        btn5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn5.setForeground(new java.awt.Color(153, 0, 0));
        btn5.setText("5");
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        jPanel2.add(btn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 490, -1, -1));

        btn6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn6.setForeground(new java.awt.Color(153, 0, 0));
        btn6.setText("6");
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });
        jPanel2.add(btn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 490, -1, -1));

        btn1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn1.setForeground(new java.awt.Color(153, 0, 0));
        btn1.setText("1");
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        jPanel2.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 550, -1, -1));

        btn2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn2.setForeground(new java.awt.Color(153, 0, 0));
        btn2.setText("2");
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        jPanel2.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 550, -1, -1));

        btn3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn3.setForeground(new java.awt.Color(153, 0, 0));
        btn3.setText("3");
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        jPanel2.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 550, -1, -1));

        btnpi.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnpi.setForeground(new java.awt.Color(153, 0, 0));
        btnpi.setText("π");
        btnpi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpiActionPerformed(evt);
            }
        });
        jPanel2.add(btnpi, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 610, -1, -1));

        btndot.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btndot.setForeground(new java.awt.Color(153, 0, 0));
        btndot.setText(".");
        btndot.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndotActionPerformed(evt);
            }
        });
        jPanel2.add(btndot, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 610, 40, -1));

        btn0.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btn0.setForeground(new java.awt.Color(153, 0, 0));
        btn0.setText("0");
        btn0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn0ActionPerformed(evt);
            }
        });
        jPanel2.add(btn0, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 610, -1, -1));

        btnplus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnplus.setForeground(new java.awt.Color(153, 0, 0));
        btnplus.setText("+");
        btnplus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplusActionPerformed(evt);
            }
        });
        jPanel2.add(btnplus, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 500, 50, 90));

        btnminus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnminus.setForeground(new java.awt.Color(153, 0, 0));
        btnminus.setText("-");
        btnminus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnminusActionPerformed(evt);
            }
        });
        jPanel2.add(btnminus, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 500, 50, 90));

        btnback.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnback.setForeground(new java.awt.Color(153, 0, 0));
        btnback.setText("back");
        btnback.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbackActionPerformed(evt);
            }
        });
        jPanel2.add(btnback, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 610, -1, -1));

        btnequal.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnequal.setForeground(new java.awt.Color(153, 0, 0));
        btnequal.setText("=");
        btnequal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnequalActionPerformed(evt);
            }
        });
        jPanel2.add(btnequal, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 610, 80, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 562, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 663, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNormalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNormalActionPerformed
       
        new Calculator().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnNormalActionPerformed

    private void btnAC1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAC1ActionPerformed
      
        display.setText("0");
    }//GEN-LAST:event_btnAC1ActionPerformed

    private void btnhexaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhexaActionPerformed
    
        int n=Integer.parseInt(display.getText());
        display.setText(Integer.toString(n,16));
    }//GEN-LAST:event_btnhexaActionPerformed

    private void btnoctalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnoctalActionPerformed
      
        int n=Integer.parseInt(display.getText());
        display.setText(Integer.toString(n,8));
    }//GEN-LAST:event_btnoctalActionPerformed

    private void btnbinaryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbinaryActionPerformed
       
        int n=Integer.parseInt(display.getText());
        display.setText(Integer.toString(n,2));
    }//GEN-LAST:event_btnbinaryActionPerformed

    private void btnlnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlnActionPerformed
       
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        pm=Math.log(pm);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlnActionPerformed

    private void btnconstantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconstantActionPerformed
      
        new ScientificConstants().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnconstantActionPerformed

    private void btnsinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsinActionPerformed
     

        double pm=Double.parseDouble(String.valueOf(display.getText()));
        double s=Math.toRadians(pm);
        double x=(Math.sin(s));
        display.setText(String.valueOf(x));
        
  
    }//GEN-LAST:event_btnsinActionPerformed

    private void btncosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncosActionPerformed
      
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        double s=Math.toRadians(pm);
        double x=Math.cos(s);
        display.setText(String.valueOf(x));
    }//GEN-LAST:event_btncosActionPerformed

    private void btntanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntanActionPerformed
    
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        double s=Math.toRadians(pm);
        double x=Math.tan(s);
        display.setText(String.valueOf(x));
    }//GEN-LAST:event_btntanActionPerformed

    private void btnlogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlogActionPerformed
        
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        
        pm=Math.log10(pm);
        
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnlogActionPerformed

    private void btnconversionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconversionActionPerformed
       

        new ScientificConvertor().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnconversionActionPerformed

    private void btnsininverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsininverseActionPerformed
      
        double pm=Double.parseDouble(String.valueOf(display.getText()));

        double s=Math.asin(pm);

        double mn= Math.toDegrees(s);

        display.setText(String.valueOf(mn));
    }//GEN-LAST:event_btnsininverseActionPerformed

    private void btncosinverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncosinverseActionPerformed
    
        double pm=Double.parseDouble(String.valueOf(display.getText()));

        double s=Math.acos(pm);

        double mn= Math.toDegrees(s);

        display.setText(String.valueOf(mn));
    }//GEN-LAST:event_btncosinverseActionPerformed

    private void btntaninverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btntaninverseActionPerformed
  
        double pm=Double.parseDouble(String.valueOf(display.getText()));

        double s=Math.atan(pm);

        double mn= Math.toDegrees(s);

        display.setText(String.valueOf(mn));
    }//GEN-LAST:event_btntaninverseActionPerformed

    private void btnrundActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrundActionPerformed
        
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        pm=Math.round(pm);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnrundActionPerformed

    private void btnrootActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrootActionPerformed
      
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        pm=Math.sqrt(pm);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnrootActionPerformed

    private void btnquebeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnquebeActionPerformed
      
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        pm=pm*pm*pm;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnquebeActionPerformed

    private void btninverseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninverseActionPerformed
      
        firstnumber=Double.parseDouble(display.getText());

        double sp=Math.pow(firstnumber,-1);
        display.setText(String.valueOf(sp));
    }//GEN-LAST:event_btninverseActionPerformed

    private void btnsquareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsquareActionPerformed
        
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        pm=pm*pm;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnsquareActionPerformed

    private void btnnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnActionPerformed
    
        double pm=Double.parseDouble(String.valueOf(display.getText()));
        double k=Math.pow(pm,pm);
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnnActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
    
        String num = display.getText()+btn7.getText();
        display.setText(num);
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        // TODO add your handling code here:
        String num = display.getText()+btn8.getText();
        display.setText(num);
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
       
        String num = display.getText()+btn9.getText();
        display.setText(num);
    }//GEN-LAST:event_btn9ActionPerformed

    private void btnmultiplicationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmultiplicationActionPerformed
       
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("*");
    }//GEN-LAST:event_btnmultiplicationActionPerformed

    private void btndivideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndivideActionPerformed
        
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("/");
    }//GEN-LAST:event_btndivideActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        
        String num = display.getText()+btn4.getText();
        display.setText(num);
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
   
        String num = display.getText()+btn5.getText();
        display.setText(num);
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
    
        String num = display.getText()+btn6.getText();
        display.setText(num);
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
       
        String num = display.getText()+btn1.getText();
        display.setText(num);
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
    
        String num = display.getText()+btn2.getText();
        display.setText(num);
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
     
        String num = display.getText()+btn3.getText();
        display.setText(num);
    }//GEN-LAST:event_btn3ActionPerformed

    private void btnpiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpiActionPerformed
    
        double pm;
        pm=3.141592653589793238462643832795;
        display.setText(String.valueOf(pm));
    }//GEN-LAST:event_btnpiActionPerformed

    private void btndotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndotActionPerformed
       

        if(!display.getText().contains("."))
        {
            display.setText(display.getText()+btndot.getText());
        }
    }//GEN-LAST:event_btndotActionPerformed

    private void btn0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn0ActionPerformed
        String num = display.getText()+btn0.getText();
        display.setText(num);
    }//GEN-LAST:event_btn0ActionPerformed

    private void btnplusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplusActionPerformed
       
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("+");
    }//GEN-LAST:event_btnplusActionPerformed

    private void btnminusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnminusActionPerformed
       
        firstnumber=Double.parseDouble(display.getText());
        display.setText(null);
        operation=("-");
    }//GEN-LAST:event_btnminusActionPerformed

    private void btnbackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbackActionPerformed
    
        String bsp;
        bsp = null;

        if(display.getText().length()>0)
        {
            StringBuilder ns = new StringBuilder(display.getText());
            ns.deleteCharAt(display.getText().length()-1);
            bsp=ns.toString();
            display.setText(bsp);
        }
    }//GEN-LAST:event_btnbackActionPerformed

    private void btnequalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnequalActionPerformed
    
        String g12;
        secondnumber=Double.parseDouble(display.getText());

        if(null!=operation)
        switch (operation) {
            case "+":
                result=firstnumber+secondnumber;
                g12=String.format("%.2f",result);
                display.setText(g12);
                break;
            case "-":
                result=firstnumber-secondnumber;
                g12=String.format("%.2f",result);
                display.setText(g12);
                break;
            case "*":
                result=firstnumber*secondnumber;
                g12=String.format("%.2f",result);
                display.setText(g12);
                break;
            case "/":
                result=firstnumber/secondnumber;
                g12=String.format("%.2f",result);
                display.setText(g12);
                break;
            case "%":
                result=firstnumber%secondnumber;
                g12=String.format("%.2f",result);
                display.setText(g12);
                break;
            default:
                break;
        }
    }//GEN-LAST:event_btnequalActionPerformed

    private void displayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayActionPerformed
      
    }//GEN-LAST:event_displayActionPerformed

   
    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new scientific_Cal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn0;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn5;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton btn8;
    private javax.swing.JButton btn9;
    private javax.swing.JButton btnAC1;
    private javax.swing.JButton btnNormal;
    private javax.swing.JButton btnback;
    private javax.swing.JButton btnbinary;
    private javax.swing.JButton btnconstant;
    private javax.swing.JButton btnconversion;
    private javax.swing.JButton btncos;
    private javax.swing.JButton btncosinverse;
    private javax.swing.JButton btndivide;
    private javax.swing.JButton btndot;
    private javax.swing.JButton btnequal;
    private javax.swing.JButton btnhexa;
    private javax.swing.JButton btninverse;
    private javax.swing.JButton btnln;
    private javax.swing.JButton btnlog;
    private javax.swing.JButton btnminus;
    private javax.swing.JButton btnmultiplication;
    private javax.swing.JButton btnn;
    private javax.swing.JButton btnoctal;
    private javax.swing.JButton btnpi;
    private javax.swing.JButton btnplus;
    private javax.swing.JButton btnquebe;
    private javax.swing.JButton btnroot;
    private javax.swing.JButton btnrund;
    private javax.swing.JButton btnsin;
    private javax.swing.JButton btnsininverse;
    private javax.swing.JButton btnsquare;
    private javax.swing.JButton btntan;
    private javax.swing.JButton btntaninverse;
    private javax.swing.JTextField display;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
