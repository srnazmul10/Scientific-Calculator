
package Scientific;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JOptionPane;


public class ScientificConvertor extends javax.swing.JFrame {

  
    public ScientificConvertor() {
        initComponents();
          Toolkit toolkit=getToolkit();
        Dimension size=toolkit.getScreenSize();
        setLocation(size.width/2-getWidth()/2,size.height/2-getHeight()/2);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        select = new javax.swing.JComboBox<>();
        lbl1 = new javax.swing.JLabel();
        result = new javax.swing.JLabel();
        btn1 = new javax.swing.JButton();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        txt1 = new javax.swing.JTextField();
        btn4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 51, 51));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 0), 5));
        jPanel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        select.setBackground(new java.awt.Color(0, 204, 0));
        select.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        select.setForeground(new java.awt.Color(153, 0, 0));
        select.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select one of the following", "Km to meter", "meter to km ", "km to miles", "miles to km", "cm to feet", "feet to cm", "yard to cm", "cm to yard", "celcius to fahrenheit", "celcius to kelvin", "fahrenheit to celcius", "fahrenheit to kelvin", "kelvin to celcius", "kelvin to fahrenheit", " " }));
        select.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 4));
        jPanel1.add(select, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 60, 430, 53));

        lbl1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lbl1.setForeground(new java.awt.Color(0, 204, 204));
        lbl1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl1.setText("Enter  an amount to convert :");
        lbl1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255), 3));
        jPanel1.add(lbl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 160, -1, 45));

        result.setBackground(new java.awt.Color(51, 153, 0));
        result.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        result.setForeground(new java.awt.Color(255, 255, 255));
        result.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153), 4));
        jPanel1.add(result, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 280, 360, 52));

        btn1.setBackground(new java.awt.Color(0, 102, 0));
        btn1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btn1.setText("GO BACK");
        btn1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 430, 169, 46));

        btn2.setBackground(new java.awt.Color(0, 102, 0));
        btn2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btn2.setText("Convert");
        btn2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        jPanel1.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, 164, 46));

        btn3.setBackground(new java.awt.Color(0, 153, 0));
        btn3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btn3.setText("Reset");
        btn3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        jPanel1.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 430, 169, 46));

        txt1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        txt1.setForeground(new java.awt.Color(153, 0, 0));
        txt1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txt1.setAutoscrolls(false);
        txt1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 153), 4));
        jPanel1.add(txt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 160, 308, 45));

        btn4.setBackground(new java.awt.Color(51, 51, 0));
        btn4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btn4.setText("Backspace");
        btn4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(255, 255, 255), 2, true));
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        jPanel1.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 430, 169, 46));

        jLabel1.setBackground(new java.awt.Color(204, 51, 0));
        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 255, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("RESULT");
        jLabel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 0, 0), 5));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 160, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 545, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        // TODO add your handling code here:
       new  scientific_Cal().setVisible(true);
        this.setVisible(false); 
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        
        txt1.setText("0");
        result.setText("0");
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        
         double x=Double.parseDouble(txt1.getText());
         double y;
         
         if((txt1.getText().equals("")))
        {
            JOptionPane.showMessageDialog(null,"You must select an item to convert",
                    "System",JOptionPane.INFORMATION_MESSAGE);
        }
        
         else if(select.getSelectedItem().equals("Km to meter"))
         {
            y=(1000*x);
            
            String Result=String.format("%.2f",y);
            result.setText(Result);
         }
         
         else if(select.getSelectedItem().equals("meter to km"))
         {
             y=(x/1000);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("km to miles"))
         {
             y=(x*0.62);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("miles to km"))
         {
             y=(x*1.61);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("cm to feet"))
         {
             y=(x*0.0328084);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("feet to cm"))
         {
             y=(x*30.48);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("yard to cm"))
         {
             y=(x*91.44);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("cm to yard"))
         {
             y=(x*0.0109361);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("celcius to fahrenheit"))
         {
             y=(((9*x)/5)+(32));
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("celcius to kelvin"))
         {
             y=(x+273.15);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("fahrenheit to celcius"))
         {
             y=((x-32)*(5/9));
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("fahrenheit to kelvin"))
         {
             y=((x-32)*(5/9)+273.15);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("kelvin to celcius"))
         {
             y=(x-273.15);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
          else if(select.getSelectedItem().equals("kelvin to fahrenheit"))
         {
             y=((x-273.15)*(9/5)+32);
             String Result=String.format("%.2f",y);
             result.setText(Result);
         }
         else
          {
              JOptionPane.showMessageDialog(null,"You must select an item to convert",
                    "System",JOptionPane.INFORMATION_MESSAGE);
              
          }
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
      
         String bsp=null;
        
        if(txt1.getText().length()>0)
        {
            StringBuilder ns = new StringBuilder(txt1.getText());
            ns.deleteCharAt(txt1.getText().length()-1);
            bsp=ns.toString();
            txt1.setText(bsp);
        }
    }//GEN-LAST:event_btn4ActionPerformed

   
    public static void main(String args[]) {
        
   
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScientificConvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScientificConvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScientificConvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScientificConvertor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScientificConvertor().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel result;
    private javax.swing.JComboBox<String> select;
    private javax.swing.JTextField txt1;
    // End of variables declaration//GEN-END:variables
}
